import sys, datetime, hashlib, hmac
import requests  # pip3 install requests
import urllib
import os
import json
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.credentials import ReadOnlyCredentials
from types import SimpleNamespace
from argparse import RawTextHelpFormatter
from argparse import ArgumentParser
print("Imports Completed")

protocol = 'https'
access_key = os.getenv('AWS_ACCESS_KEY_ID', '')
secret_key = os.getenv('AWS_SECRET_ACCESS_KEY', '')
region = os.getenv('SERVICE_REGION', '')
session_token = os.getenv('AWS_SESSION_TOKEN', '')

def lambda_handler(event, context):

    global region
    region = os.getenv('AWS_REGION', '')
    host = "my-neptune-database.cluster-cchrgz0mtxgh.us-east-1.neptune.amazonaws.com:8182"#event['host']
    method = event['method']
    query_type = event['query_type']
    prefix = event['prefix']
    query =  event['query']

    return make_signed_request(host, method, query_type, prefix, query)

def validate_input(method, query_type):
    if (method != 'GET' and method != 'POST'):
        print('First parameter must be "GET" or "POST", but is "' + method + '".')
        sys.exit()
    if (method == 'GET' and query_type == 'sparqlupdate'):
        print('SPARQL UPDATE is not supported in GET mode. Please choose POST.')
        sys.exit()

def get_canonical_uri_and_payload(query_type, query, method):
    if (query_type == 'sparql'):
        canonical_uri = '/sparql/'
        payload = {'query': query}

    elif (query_type == 'sparqlupdate'):
        canonical_uri = '/sparql/'
        payload = {'update': query}

    elif (query_type == 'gremlin'):
        canonical_uri = '/gremlin/'
        payload = {'gremlin': query}
        if (method == 'POST'):
            payload = json.dumps(payload)

    elif (query_type == 'openCypher'):
        canonical_uri = '/openCypher/'
        payload = {'query': query}

    elif (query_type == "loader"):
        canonical_uri = "/loader/"
        payload = json.loads(query)

    elif (query_type == "status"):
        canonical_uri = "/status/"
        payload = {}

    elif (query_type == "gremlin/status"):
        canonical_uri = "/gremlin/status/"
        payload = {}

    elif (query_type == "openCypher/status"):
        canonical_uri = "/openCypher/status/"
        payload = {}

    elif (query_type == "sparql/status"):
        canonical_uri = "/sparql/status/"
        payload = {}

    else:
        print(
            'Third parameter should be from ["gremlin", "sparql", "sparqlupdate", "loader", "status] but is "' + query_type + '".')
        sys.exit()
    return canonical_uri, payload

def get_subject_list(text):
    required_values=[]
    required_values_test=[]
    print('text',text)
    for i in text['results']['bindings']:
        print("That's my subject",i['s']['value'])
        required_values.append('<'+i['s']['value']+'>')
        #required_values.append(i['s']['value'].rsplit('/', 1)[0]+"/"+i['s']['value'].split('/')[-1])
        print("required_values",required_values)
        #required_values.append(str(i['s']['value']))
        #print("required_values",required_values)
    required_values.sort()
    print(required_values)
    return required_values


def get_triples_list(text):
    #print('Entered in get_triples_list and starting the loop')
    main_op={}
    #print('text_results_bindings'+ str(text['results']['bindings']))
    for i in text['results']['bindings']:
        temp=dict()
        temp['id']=i['s']['value'].split('/')[-1]
        if (i['o']['type']!='uri'):
            temp[i['p']['value'].split('/')[-1]]=i['o']['value']
        else:
            temp[i['p']['value'].split('/')[-1]]=i['o']['value'].split('/')[-1]
        #print(temp)
        if i['s']['value'] in list(main_op.keys()):
            if (i['p']['value'].split('/')[-1]) in main_op[i['s']['value']]:
                temp[i['p']['value'].split('/')[-1]] = str(temp[i['p']['value'].split('/')[-1]]) + ', ' + (main_op[i['s']['value']][i['p']['value'].split('/')[-1]])
                print(temp[i['p']['value'].split('/')[-1]])
            main_op[i['s']['value']].update(temp)
        else:
            main_op[i['s']['value']]=temp
        #print(main_op)
    #print('In Get_triples_list and exiting the loop')
    main_op = sorted(list(main_op.values()), key=lambda d: d['id']) 
    #return list(main_op.values())
    return main_op

def make_signed_request(host, method, query_type, prefix, query):
    service = 'neptune-db'
    endpoint = protocol + '://' + host

    print()
    print('+++++ USER INPUT +++++')
    print('host = ' + host)
    print('method = ' + method)
    print('query_type = ' + query_type)
    query=query
    print('query = ' + query)

    validate_input(method, query_type)
    canonical_uri, payload = get_canonical_uri_and_payload(query_type, query, method)
    print(payload)
    print('payload = {}'.format(payload))

    data = payload if method == 'POST' else None
    params = payload if method == 'GET' else None
    request_url = endpoint + canonical_uri
    creds = SimpleNamespace(
        access_key=access_key, secret_key=secret_key, token=session_token, region=region,
    )
    request = AWSRequest(method=method, url=request_url, data=data, params=params)
    SigV4Auth(creds, service, region).add_auth(request)
    r = None

    # ************* SEND THE REQUEST *************
    if (method == 'GET'):

        print('++++ BEGIN GET REQUEST +++++')
        print('Request URL = ' + request_url)
        print('request.headers = ' + str(request.headers))
        print('params = ' + str(params))
        try:
            r = requests.get(request_url, headers=request.headers, verify=False, params=params)
        except:
            print("failed ")
        print(r)

    elif (method == 'POST'):

        print('\n+++++ BEGIN POST REQUEST +++++')
        print('Request URL = ' + type(request_url))
        #print(data)
        r = requests.post(request_url, headers=request.headers, verify=True, data=data)
        #print(r)

    else:
        print('Request method is neither "GET" nor "POST", something is wrong here.')

    if r:
        print("enter the if cluse")
        print('+++++ RESPONSE +++++')
        print('Response code: %d\n' % r.status_code)
        response = r.text
        print('printing the response::' , response)
        req_response_data=r.text.replace('#','/')
        #req_response_data=r.text
        text=json.loads(req_response_data)
        r.close()
        if query_type=='sparql' and method == 'GET':
           # print('entered in block 1')
            subject_list=get_subject_list(text)
            print("subject_list",subject_list)
            subject_text=('(' + ', '.join(subject_list) + ')')
            second_query=prefix+' select ?s ?p ?o where { ?s ?p ?o . FILTER(?s in '+subject_text+') }'
            second_payload={'query':second_query}
            print('printing the second payload',second_payload)
            r2 = requests.post(request_url, headers=request.headers, verify=True, data=second_payload)
            req_response_data=r2.text.replace('#','/')
            print("req_response_data",req_response_data)
            #req_response_data=r2.text
            print('printing the req_response_data:: ' + str(req_response_data))
            return (get_triples_list(json.loads(req_response_data)))
            #return  text['results']['bindings']
        elif query_type=='sparqlupdate' and method == 'POST' and r.status_code==200 :
            #print('entered in block 2')
            return  'Success'
        elif query_type=='sparqlupdate' and method == 'POST' and r.status_code!=200 :
            #print('entered in block 3')
            return  'Failed'
        else:
            #print('entered in block 4')
            return response
        